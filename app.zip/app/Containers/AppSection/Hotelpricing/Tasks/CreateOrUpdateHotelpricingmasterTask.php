<?php

namespace App\Containers\AppSection\Hotelpricing\Tasks;

use App\Containers\AppSection\Hotelpricing\Data\Repositories\HotelpricingRepository;
use App\Containers\AppSection\Hotelpricing\Models\Hotelpricing;
use App\Ship\Exceptions\CreateResourceFailedException;
use App\Ship\Parents\Tasks\Task as ParentTask;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Apiato\Core\Traits\HashIdTrait;
use App\Containers\AppSection\Hotelmaster\Models\Hotelmaster;
use App\Containers\AppSection\Hotelroom\Models\Hotelroom;
use App\Containers\AppSection\Tenantuser\Models\Tenantuser;

class CreateOrUpdateHotelpricingmasterTask extends ParentTask
{
    use HashIdTrait;
    public function __construct(
        protected HotelpricingRepository $repository
    ) {}

    public function run($request)
    {
        try {
            $user_id = $this->decode($request->user_id);
            $hotel_master_id = $this->decode($request->hotel_master_id);
            $hotelflag = Hotelmaster::find($hotel_master_id);
            if ($hotelflag) {
                if ($request->rooms != null) {
                    if (count($request->rooms) >= 1) {
                        foreach ($request->rooms as $roomData) {
                            $room_id = $this->decode($roomData['id']);
                            $actroomData = Hotelroom::where('id', $room_id)->first();
                            if ($actroomData != null) {
                                $condition = array();
                                $newData = array();
                                $hotelPricing = $roomData['hotel_pricing'];
                                $condition['hotel_master_id'] = $hotel_master_id;
                                $condition['room_id'] = $room_id;
                                $newData['basic_price'] = $hotelPricing['basic_price'];
                                $newData['ep'] = $hotelPricing['ep'];
                                $newData['cp'] = $hotelPricing['cp'];
                                $newData['map'] = $hotelPricing['map'];
                                $newData['ap'] = $hotelPricing['ap'];
                                $newData['extra_bed'] = $hotelPricing['extra_bed'];
                                $newData['toddler'] = $hotelPricing['toddler'];
                                $existingRecord = Hotelpricing::where($condition)->first();
                                if ($existingRecord) {
                                    $createData = $existingRecord->update($newData);
                                } else {
                                    $newData['created_by'] = $user_id;
                                    $createData = Hotelpricing::create(array_merge($condition, $newData));
                                }
                            } else {
                                $returnData['result'] = false;
                                $returnData['message'] = "Room Not Found";
                                $returnData['object'] = "Hotelpricing Master";
                            }
                        }
                        $returnData['result'] = true;
                        $returnData['message'] = "Hotel Pricing Updated Successfully";
                        $returnData['object'] = "Hotelpricing Master";
                    }
                } else {
                    $returnData['result'] = false;
                    $returnData['message'] = "Rooms Not Found";
                    $returnData['object'] = "Hotelpricing Master";
                }
            } else {
                $returnData['result'] = false;
                $returnData['message'] = "Hotel Id is Invalid";
                $returnData['object'] = "Hotelpricing Master";
            }
            return $returnData;
        } catch (Exception $e) {
            return [
                'result' => false,
                'message' => 'Error: Failed to create the resource. Please try again later.',
                'object' => 'Hotelpricings',
                'data' => [],
            ];
        }
    }
}

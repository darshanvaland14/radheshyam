<?php

namespace App\Containers\AppSection\User\Tests;

class FunctionalTestCase extends ContainerTestCase
{
}

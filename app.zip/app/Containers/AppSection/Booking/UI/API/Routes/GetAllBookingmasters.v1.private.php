<?php

/**
 * @apiGroup           Booking
 * @apiName            getAllBookingmasters
 *
 * @api                {GET} /v1/getallBookingmasters Get All Booking
 * @apiDescription     Endpoint description here...
 *
 * @apiVersion         1.0.0
 * @apiPermission      Authenticated ['permissions' => '', 'Bookings' => '']
 *
 * @apiHeader          {String} accept=application/json
 * @apiHeader          {String} authorization=Bearer
 *
 * @apiParam           {String} parameters here...
 *
 * @apiSuccessExample  {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *     // Insert the response of the request here...
 * }
 */

use App\Containers\AppSection\Booking\UI\API\Controllers\Controller;
use Illuminate\Support\Facades\Route;

Route::get('getallbookingmasters', [Controller::class, 'getAllBookingmasters'])
    ->middleware(['auth:tenant']);

<?php

namespace App\Containers\AppSection\Booking\Tasks;

use App\Containers\AppSection\Booking\Data\Repositories\BookingRepository;
use App\Containers\AppSection\Booking\Models\Booking;
use App\Ship\Exceptions\NotFoundException;
use App\Ship\Parents\Tasks\Task as ParentTask;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Apiato\Core\Traits\HashIdTrait;
use App\Containers\AppSection\Booking\Models\Bookingroom;
use App\Containers\AppSection\Roomtype\Models\Roomtype;

class FindBookingmasterByHotelIdTask extends ParentTask
{
    use HashIdTrait;
    public function __construct(
        protected BookingRepository $repository
    ) {}

    public function run($id)
    {
        try {
            $getData = Booking::where('hotel_master_id', $id)->paginate(10);
            if (!empty($getData) && count($getData) >= 1) {
                $returnData['result'] = true;
                $returnData['message'] = "Data found";
                $returnData['hotel_master_id'] = $this->encode($id);
                for ($i = 0; $i < count($getData); $i++) {
                    $booking = [];
                    $booking['id'] = $this->encode($getData[$i]->id);
                    $booking['booking_id'] = $getData[$i]->booking_id;
                    $booking['booking_date'] =  $getData[$i]->booking_date;
                    $booking['customer_name'] =  $getData[$i]->customer_name;
                    $booking['email'] =  $getData[$i]->email;
                    $booking['address'] =  $getData[$i]->address;
                    $booking['mobile_no'] =  $getData[$i]->mobile_no;
                    $booking['booking_start_date'] =  $getData[$i]->booking_start_date;
                    $booking['booking_end_date'] =  $getData[$i]->booking_end_date;
                    $booking['notes'] =  $getData[$i]->notes;
                    $booking['no_of_rooms'] =  $getData[$i]->no_of_rooms;
                    $booking['total_amount'] =  $getData[$i]->total_amount;
                    $booking['total_tax'] =  $getData[$i]->total_tax;
                    $booking['advance_amount'] =  $getData[$i]->advance_amount;
                    $booking['due_amount'] =  $getData[$i]->due_amount;
                    $booking['created_at'] = $getData[$i]->created_at;
                    $booking['updated_at'] = $getData[$i]->updated_at;
                    $getBookingRoomData = Bookingroom::where('booking_id', $getData[$i]->id)->get();
                    if (!empty($getBookingRoomData) && count($getBookingRoomData) >= 1) {
                        for ($j = 0; $j < count($getBookingRoomData); $j++) {
                            $bookingRoom = [];
                            $booking['booking_room_flag'] = true;
                            $bookingRoom['id'] = $this->encode($getBookingRoomData[$j]->id);
                            $bookingRoom['room_id'] = $this->encode($getBookingRoomData[$j]->room_id);
                            $roomTypeName = Roomtype::where('id', $getBookingRoomData[$j]->room_type_id)->first();
                            $bookingRoom['room_type_id'] = $this->encode($getBookingRoomData[$j]->room_type_id);
                            $bookingRoom['room_type_name'] = $roomTypeName->name;
                            $bookingRoom['no_of_room'] = $getBookingRoomData[$j]->no_of_room;
                            $bookingRoom['basic_price'] = $getBookingRoomData[$j]->basic_price;
                            $bookingRoom['ep'] = $getBookingRoomData[$j]->ep;
                            $bookingRoom['cp'] = $getBookingRoomData[$j]->cp;
                            $bookingRoom['map'] = $getBookingRoomData[$j]->map;
                            $bookingRoom['ap'] = $getBookingRoomData[$j]->ap;
                            $bookingRoom['extra_bed_qty'] = $getBookingRoomData[$j]->extra_bed_qty;
                            $bookingRoom['extra_bed_price'] = $getBookingRoomData[$j]->extra_bed_price;
                            $bookingRoom['tax_amount'] = $getBookingRoomData[$j]->tax_amount;
                            $bookingRoom['created_at'] = $getBookingRoomData[$j]->created_at;
                            $bookingRoom['updated_at'] = $getBookingRoomData[$j]->updated_at;
                            $booking['booking_rooms'][] = $bookingRoom;
                        }
                    }
                    $returnData['data']['bookings'][] = $booking;
                }
                // $returnData['meta']['pagination']['total'] = $getData->total();
                // $returnData['meta']['pagination']['count'] = $getData->count();
                // $returnData['meta']['pagination']['per_page'] = $getData->perPage();
                // $returnData['meta']['pagination']['current_page'] = $getData->currentPage();
                // $returnData['meta']['pagination']['total_pages'] = $getData->lastPage();
                // $returnData['meta']['pagination']['links']['previous'] = $getData->previousPageUrl();
                // $returnData['meta']['pagination']['links']['next'] = $getData->nextPageUrl();
            } else {
                $returnData['result'] = false;
                $returnData['message'] = "No Data Found";
                $returnData['object'] = "Bookings";
                // $returnData['meta']['pagination']['total'] = $getData->total();
                // $returnData['meta']['pagination']['count'] = $getData->count();
                // $returnData['meta']['pagination']['per_page'] = $getData->perPage();
                // $returnData['meta']['pagination']['current_page'] = $getData->currentPage();
                // $returnData['meta']['pagination']['total_pages'] = $getData->lastPage();
                // $returnData['meta']['pagination']['links']['previous'] = $getData->previousPageUrl();
                // $returnData['meta']['pagination']['links']['next'] = $getData->nextPageUrl();
            }
            return $returnData;
        } catch (Exception $e) {
            return [
                'result' => false,
                'message' => 'Error: Failed to find the resource. Please try again later.',
                'object' => 'Bookings',
                'data' => [],
            ];
        }
    }
}

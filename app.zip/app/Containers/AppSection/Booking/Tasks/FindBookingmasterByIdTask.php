<?php

namespace App\Containers\AppSection\Booking\Tasks;

use App\Containers\AppSection\Booking\Data\Repositories\BookingRepository;
use App\Containers\AppSection\Booking\Models\Booking;
use App\Ship\Exceptions\NotFoundException;
use App\Ship\Parents\Tasks\Task as ParentTask;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Apiato\Core\Traits\HashIdTrait;
use App\Containers\AppSection\Booking\Models\Bookingroom;

class FindBookingmasterByIdTask extends ParentTask
{
    use HashIdTrait;
    public function __construct(
        protected BookingRepository $repository
    ) {}

    public function run($id)
    {
        // try {
        $getData = Booking::where('id', $id)->first();
        if ($getData != "") {
            $returnData['result'] = true;
            $returnData['message'] = "Data found";
            $returnData['data']['object'] = 'Bookings';
            $returnData['data']['id'] = $this->encode($getData->id);
            $returnData['data']['booking_id'] = $getData->booking_id;
            $returnData['data']['hotel_master_id'] = $this->encode($getData->hotel_master_id);
            $returnData['data']['booking_date'] =  $getData->booking_date;
            $returnData['data']['customer_name'] =  $getData->customer_name;
            $returnData['data']['email'] =  $getData->email;
            $returnData['data']['address'] =  $getData->address;
            $returnData['data']['mobile_no'] =  $getData->mobile_no;
            $returnData['data']['booking_start_date'] =  $getData->booking_start_date;
            $returnData['data']['booking_end_date'] =  $getData->booking_end_date;
            $returnData['data']['notes'] =  $getData->notes;
            $returnData['data']['no_of_rooms'] =  $getData->no_of_rooms;
            $returnData['data']['total_amount'] =  $getData->total_amount;
            $returnData['data']['total_tax'] =  $getData->total_tax;
            $returnData['data']['advance_amount'] =  $getData->advance_amount;
            $returnData['data']['due_amount'] =  $getData->due_amount;
            $returnData['data']['created_at'] = $getData->created_at;
            $returnData['data']['updated_at'] = $getData->updated_at;
            $bookingRoomData = Bookingroom::where('booking_id', $getData->id)->get();
            if (!empty($bookingRoomData)) {
                if (count($bookingRoomData) >= 1) {
                    for ($i = 0; $i < count($bookingRoomData); $i++) {
                        $bookingRoom = [];
                        $returnData['data']['booking_room_flag'] = true;
                        $bookingRoom['id'] = $this->encode($bookingRoomData[$i]->id);
                        $bookingRoom['room_id'] = $this->encode($bookingRoomData[$i]->room_id);
                        $bookingRoom['room_type_id'] = $this->encode($bookingRoomData[$i]->room_type_id);
                        $bookingRoom['no_of_room'] = $bookingRoomData[$i]->no_of_room;
                        $bookingRoom['basic_price'] = $bookingRoomData[$i]->basic_price;
                        $bookingRoom['ep'] = $bookingRoomData[$i]->ep;
                        $bookingRoom['cp'] = $bookingRoomData[$i]->cp;
                        $bookingRoom['map'] = $bookingRoomData[$i]->map;
                        $bookingRoom['ap'] = $bookingRoomData[$i]->ap;
                        $bookingRoom['extra_bed_qty'] = $bookingRoomData[$i]->extra_bed_qty;
                        $bookingRoom['extra_bed_price'] = $bookingRoomData[$i]->extra_bed_price;
                        $bookingRoom['total_amount'] = $bookingRoomData[$i]->total_amount;
                        $bookingRoom['tax_amount'] = $bookingRoomData[$i]->tax_amount;
                        $bookingRoom['created_at'] = $bookingRoomData[$i]->created_at;
                        $bookingRoom['updated_at'] = $bookingRoomData[$i]->updated_at;
                        $returnData['data']['booking_rooms'][] = $bookingRoom;
                    }
                } else {
                    $bookingRoom['booking_room_flag'] = false;
                }
            } else {
                $bookingRoom['booking_room_flag'] = false;
            }
        } else {
            $returnData['result'] = false;
            $returnData['message'] = "No Data Found";
            $returnData['object'] = "Bookings";
        }
        return $returnData;
        // } catch (Exception $e) {
        //     return [
        //         'result' => false,
        //         'message' => 'Error: Failed to find the resource. Please try again later.',
        //         'object' => 'Bookings',
        //         'data' => [],
        //     ];
        // }
    }
}

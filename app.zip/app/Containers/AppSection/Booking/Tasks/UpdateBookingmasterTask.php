<?php

namespace App\Containers\AppSection\Booking\Tasks;

use App\Containers\AppSection\Booking\Data\Repositories\BookingRepository;
use App\Containers\AppSection\Booking\Models\Booking;
use App\Ship\Exceptions\NotFoundException;
use App\Ship\Exceptions\UpdateResourceFailedException;
use App\Ship\Parents\Tasks\Task as ParentTask;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Apiato\Core\Traits\HashIdTrait;
use App\Containers\AppSection\Booking\Models\Bookingroom;
use App\Containers\AppSection\Hotelpricing\Models\Hotelpricing;
use App\Containers\AppSection\Hotelroom\Models\Hotelroom;

class UpdateBookingmasterTask extends ParentTask
{
    use HashIdTrait;
    public function __construct(
        protected BookingRepository $repository
    ) {}

    public function run($data, $request)
    {
        // try {
        $condition = [
            "id" => $this->decode($request->booking_id)
        ];
        $bookingData = Booking::where('id', $this->decode($request->booking_id))->first();
        if ($bookingData) {
            $bookingData->update($data);
        }
        // $bookingData = Booking::where('id', $this->decode($request->booking_id))->first();
        $bookedRooms = Bookingroom::where('booking_id', $condition['id'])->get();

        if ($bookedRooms != null) {
            if (count($bookedRooms) >= 1) {
                $total_amount = 0.00;
                $total_tax = 0.00;
                $room_count = 0;
                $tax_rate = 0.18;
                $curr_room_delete = array();
                $curr_room_update = array();
                $u = 0;
                $r = 0;
                for ($q = 0; $q < count($bookedRooms); $q++) {
                    $found = 0;
                    foreach ($request->booking_rooms as $roomData) {
                        if ($roomData['id'] != NULL) {
                            // check for update
                            if ($bookedRooms[$q]->id == $this->decode($roomData['id'])) {
                                $found = 1;
                            }
                        }
                    }
                    if ($found == 0) {
                        $curr_room_delete[$r] = $bookedRooms[$q]->id;
                        $r++;
                    } else {
                        $curr_room_update[$u] = $bookedRooms[$q]->id;
                        $u++;
                    }
                }
                foreach ($curr_room_delete as $deleteId) {
                    $removeroom = Bookingroom::find($deleteId);
                    if ($removeroom) {
                        $room = Hotelroom::find($removeroom->room_id);
                        if ($room) {
                            $room->status = "available";
                            if ($room->save()) {
                                $removeroom->delete();
                            }
                        }
                    }
                }
                for ($up = 0; $up < count($curr_room_update); $up++) {
                    foreach ($request->booking_rooms as $roomData) {
                        if ($curr_room_update[$up] == $this->decode($roomData['id'])) {
                            $room = Hotelroom::find($this->decode($roomData['room_id']));
                            $hotelPricing = Hotelpricing::where('hotel_master_id', $bookingData->hotel_master_id)
                                ->where('room_id', $room->id)
                                ->first();
                            $total_amount_room = $hotelPricing->basic_price + $hotelPricing->ep + $hotelPricing->cp + $hotelPricing->map + $hotelPricing->ap + $roomData['extra_bed_price'];
                            $total_tax_room = $total_amount_room * $tax_rate;
                            $bookingRoomDataCondition = [
                                'booking_id' => $bookingData->id,
                                'room_id' => $room->id,
                            ];
                            $bookingRoomData = Bookingroom::where('booking_id', $bookingData->id)->where('room_id', $room->id)->first();
                            if ($bookingRoomData) {
                                $bookingRoomData->update([
                                    'room_type_id' => $room->room_type_id,
                                    'no_of_room' => $room->room_number,
                                    'basic_price' => $hotelPricing->basic_price,
                                    'ep' => $hotelPricing->ep,
                                    'cp' => $hotelPricing->cp,
                                    'map' => $hotelPricing->map,
                                    'ap' => $hotelPricing->ap,
                                    'extra_bed_qty' => $roomData['extra_bed_qty'],
                                    'extra_bed_price' => $roomData['extra_bed_price'],
                                    'total_amount' => $total_amount_room,
                                    'tax_amount' => $total_tax_room
                                ]);
                                if ($bookingRoomData !== null) {
                                    $room->status = 'booked';
                                    $room->save();
                                }
                            }
                        }
                    }
                }
                foreach ($request->booking_rooms as $roomData) {
                    if ($roomData['id'] == NULL) {
                        // Add
                        $room = Hotelroom::find($this->decode($roomData['room_id']));
                        $hotelPricing = Hotelpricing::where('hotel_master_id', $room->hotel_master_id)->where('room_id', $room->id)->first();
                        // dd($hotelPricing);
                        if ($hotelPricing != null) {
                            $total_amount_room = $hotelPricing->basic_price + $hotelPricing->ep + $hotelPricing->cp + $hotelPricing->map + $hotelPricing->ap + $roomData['extra_bed_price'];
                            $total_tax_room = $total_amount_room * $tax_rate;
                            $roomArray = [
                                'booking_id'      => $condition['id'],
                                'room_id'     => $room->id,
                                'room_type_id'         => $room->room_type_id,
                                'no_of_room'   => $room->room_number,
                                'basic_price'         => $hotelPricing->basic_price,
                                'ep'       => $hotelPricing->ep,
                                'cp'              => $hotelPricing->cp,
                                'map'       => $hotelPricing->map,
                                'ap'       => $hotelPricing->ap,
                                'extra_bed_qty'       => $roomData['extra_bed_qty'],
                                'extra_bed_price'       => $roomData['extra_bed_price'],
                                'total_amount'       => $total_amount_room,
                                'tax_amount'       =>  $total_tax_room
                            ];
                            $bookingRoomNew = Bookingroom::create($roomArray);
                        } else {
                            $returnData['result'] = false;
                            $returnData['message'] = "Hotel Pricing Not Found of" . $room->id;
                            $returnData['object'] = "Booking Master";
                            return $returnData;
                        }
                    }
                }
                $newBookedRooms = Bookingroom::where('booking_id', $condition['id'])->get();
                if ($newBookedRooms != null) {
                    if (count($newBookedRooms) >= 1) {
                        for ($q = 0; $q < count($newBookedRooms); $q++) {
                            $total_amount += $newBookedRooms[$q]->total_amount;
                            $total_tax += $newBookedRooms[$q]->tax_amount;
                            $room_count++;
                        }
                        $bookingData->no_of_rooms = $room_count;
                        $bookingData->total_amount = $total_amount;
                        $bookingData->total_tax = $total_tax;
                        $bookingData->advance_amount = $request->advance_amount;
                        $due_amount = $total_amount + $total_tax - $request->advance_amount;
                        $bookingData->due_amount = $due_amount;
                        if ($bookingData->save()) {
                            $returnData['result'] = true;
                            $returnData['message'] = "Booking Updated Successfull";
                            $returnData['object'] = "Booking Master";
                        }
                    }
                }
            }
        } else {
            $returnData['result'] = false;
            $returnData['message'] = "Rooms Not Found";
            $returnData['object'] = "Booking Master";
        }
        return $returnData;
        // } catch (Exception $e) {
        //     return [
        //         'result' => false,
        //         'message' => 'Error: Failed to update the resource. Please try again later.',
        //         'object' => 'Bookings',
        //         'data' => [],
        //     ];
        // }
    }
}

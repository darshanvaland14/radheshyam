<?php

namespace App\Containers\AppSection\Booking\Tasks;

use App\Containers\AppSection\Booking\Data\Repositories\BookingRepository;
use App\Containers\AppSection\Booking\Models\Booking;
use App\Ship\Parents\Tasks\Task as ParentTask;
use Exception;
use Apiato\Core\Traits\HashIdTrait;
use App\Containers\AppSection\Booking\Models\Bookingroom;
use App\Containers\AppSection\Hotelpricing\Models\Hotelpricing;
use App\Containers\AppSection\Hotelroom\Models\Hotelroom;

class CreateBookingmasterTask extends ParentTask
{
    use HashIdTrait;
    public function __construct(
        protected BookingRepository $repository
    ) {}

    public function run($data, $request)
    {
        // try {
        $bookingData = Booking::create($data);
        if ($bookingData) {
            if ($request->rooms != null) {
                if (count($request->rooms) >= 1) {
                    $total_amount = 0.00;
                    $total_tax = 0.00;
                    $room_count = 0;
                    $tax_rate = 0.18;
                    foreach ($request->rooms as $roomData) {
                        $total_amount_room = 0.00;
                        $total_tax_room = 0.00;
                        $room_id = $this->decode($roomData['room_id']);
                        $actroomData = Hotelroom::where('id', $room_id)->where('status', 'available')->first();
                        if ($actroomData != null) {
                            $hotelPricing = Hotelpricing::where('hotel_master_id', $data['hotel_master_id'])->where('room_id', $room_id)->first();
                            $total_amount_room = $hotelPricing->basic_price + $hotelPricing->ep + $hotelPricing->cp + $hotelPricing->map + $hotelPricing->ap + $roomData['extra_bed_price'];
                            $total_tax_room = $total_amount_room * $tax_rate;
                            $total_amount += $total_amount_room;
                            $total_tax += $total_tax_room;
                            $bookingRoomData = Bookingroom::create([
                                'booking_id' => $bookingData->id,
                                'room_id' => $room_id,
                                'room_type_id' => $actroomData->room_type_id,
                                'no_of_room' => $actroomData->room_number,
                                'basic_price' => $hotelPricing->basic_price,
                                'ep' => $hotelPricing->ep,
                                'cp' => $hotelPricing->cp,
                                'map' => $hotelPricing->map,
                                'ap' => $hotelPricing->ap,
                                'extra_bed_qty' => $roomData['extra_bed_qty'],
                                'extra_bed_price' => $roomData['extra_bed_price'],
                                'total_amount' => $total_amount_room,
                                'tax_amount' => $total_tax_room
                            ]);
                            if ($bookingRoomData !== null) {
                                $actroomData->status = 'booked';
                                $actroomData->save();
                                $room_count++;
                            }
                        } else {
                            $returnData['result'] = false;
                            $returnData['message'] = "Room Not Found";
                            $returnData['object'] = "Hotelpricing Master";
                        }
                    }
                    $bookingData->no_of_rooms = $room_count;
                    $bookingData->total_amount = $total_amount;
                    $bookingData->total_tax = $total_tax;
                    $bookingData->advance_amount = $request->advance_amount;
                    $due_amount = $total_amount + $total_tax - $request->advance_amount;
                    $bookingData->due_amount = $due_amount;
                    if ($bookingData->save()) {
                        $returnData['result'] = true;
                        $returnData['message'] = "Booking Successfull";
                        $returnData['object'] = "Booking Master";
                    }
                } else {
                    $returnData['result'] = false;
                    $returnData['message'] = "Rooms Not Found";
                    $returnData['object'] = "Booking Master";
                }
            } else {
                $returnData['result'] = false;
                $returnData['message'] = "Rooms Not Found";
                $returnData['object'] = "Booking Master";
            }
        } else {
            $returnData['result'] = false;
            $returnData['message'] = "Booking Not Created";
            $returnData['object'] = "Booking Master";
        }
        return $returnData;
        // } catch (Exception $e) {
        //     return [
        //         'result' => false,
        //         'message' => 'Error: Failed to create the resource. Please try again later.',
        //         'object' => 'Bookings',
        //         'data' => [],
        //     ];
        // }
    }
}

<?php

namespace App\Containers\AppSection\Booking\Actions;

use Apiato\Core\Exceptions\IncorrectIdException;
use App\Containers\AppSection\Booking\Models\Booking;
use App\Containers\AppSection\Booking\Tasks\CreateBookingmasterTask;
use App\Containers\AppSection\Booking\Tasks\GenerateBookingmasterBookingIdTask;
use App\Containers\AppSection\Booking\UI\API\Requests\CreateBookingmasterRequest;
use App\Ship\Exceptions\CreateResourceFailedException;
use App\Ship\Parents\Actions\Action as ParentAction;
use App\Containers\AppSection\Hotelmaster\Models\Hotelmaster;
use App\Containers\AppSection\Tenantuser\Models\Tenantuser;
use Apiato\Core\Traits\HashIdTrait;
use App\Containers\AppSection\Hotelroom\Models\Hotelroom;

class CreateBookingmasterAction extends ParentAction
{
    use HashIdTrait;
    public function run(CreateBookingmasterRequest $request)
    {
        $returnhotelData = array();
        $check = 0;
        $roomcheckData = [];
        $hotel_master_id = $this->decode($request->hotel_master_id);
        $check_hotel = Hotelmaster::find($hotel_master_id);
        if ($check_hotel == null) {
            $returnhotelData['result'] = false;
            $returnhotelData['message'] = "Hotel Id is Invalid";
            $returnhotelData['object'] = "Booking Master";
            return $returnhotelData;
        }
        if ($request->rooms != null) {
            if (count($request->rooms) >= 1) {
                foreach ($request->rooms as $roomData) {
                    $room_id = $this->decode($roomData['room_id']);

                    $actroomData = Hotelroom::where('id', $room_id)->where('status', 'available')->first();
                    if ($actroomData == null) {
                        $checkData = Hotelroom::select('id', 'room_number')->where('id', $room_id)->first();
                        $roomcheckData = [
                            'room_id' => $checkData->id,
                            'room_number' => $checkData->room_number,
                        ];
                        $check = 1;
                    }
                }
            }
        }
        if ($check == 1) {
            $returnhotelData['result'] = false;
            $returnhotelData['message'] = "Room Id is Invalid/Booked";
            $returnhotelData['object'] = "Booking Master";
            $returnhotelData['roomData'] = $roomcheckData;
            return $returnhotelData;
        }
        $bookingId = app(GenerateBookingmasterBookingIdTask::class)->run();
        $data = [
            "booking_id" => $bookingId,
            "hotel_master_id" => $this->decode($request->hotel_master_id),
            "booking_date" => $request->booking_date,
            "customer_name" => $request->customer_name,
            "email" => $request->email,
            "address" => $request->address,
            "mobile_no" => $request->mobile_no,
            "booking_start_date" => $request->booking_start_date,
            "booking_end_date" => $request->booking_end_date,
            "notes" => $request->notes,
        ];
        return app(CreateBookingmasterTask::class)->run($data, $request);
    }
}

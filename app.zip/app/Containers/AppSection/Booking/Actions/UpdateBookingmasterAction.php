<?php

namespace App\Containers\AppSection\Booking\Actions;

use Apiato\Core\Exceptions\IncorrectIdException;
use App\Containers\AppSection\Booking\Models\Booking;
use App\Containers\AppSection\Booking\Tasks\UpdateBookingmasterTask;
use App\Containers\AppSection\Booking\UI\API\Requests\UpdateBookingmasterRequest;
use App\Ship\Exceptions\NotFoundException;
use App\Ship\Exceptions\UpdateResourceFailedException;
use App\Ship\Parents\Actions\Action as ParentAction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Apiato\Core\Traits\HashIdTrait;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class UpdateBookingmasterAction extends ParentAction
{
    use HashIdTrait;
    public function run(UpdateBookingmasterRequest $request)
    {

        $returnbookingData = array();

        $booking_id = $this->decode($request->booking_id);
        $check_booking = Booking::find($booking_id);
        if ($check_booking == null) {
            $returnbookingData['result'] = false;
            $returnbookingData['message'] = "Booking Id is Invalid";
            $returnbookingData['object'] = "Booking Master";
            return $returnbookingData;
        }
        $data = [
            "booking_date" => $request->booking_date,
            "customer_name" => $request->customer_name,
            "email" => $request->email,
            "address" => $request->address,
            "mobile_no" => $request->mobile_no,
            "booking_start_date" => $request->booking_start_date,
            "booking_end_date" => $request->booking_end_date,
            "notes" => $request->notes,
        ];
        return app(UpdateBookingmasterTask::class)->run($data, $request);
    }
}

<?php

namespace App\Containers\AppSection\Booking\Models;

use App\Ship\Parents\Models\Model as ParentModel;
use App\Ship\Parents\Models\UserModel as ParentUserModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class Bookingroom extends ParentUserModel
{
    use SoftDeletes;
    protected $table = "hs_user_booking_rooms";
    protected $fillable = [
        "id",
        "booking_id",
        "room_id",
        "room_type_id",
        "no_of_room",
        "basic_price",
        "ep",
        "cp",
        "map",
        "ap",
        "extra_bed_qty",
        "extra_bed_price",
        "total_amount",
        "tax_amount",
    ];

    protected $hidden = [];

    protected $casts = [];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    /**
     * A resource key to be used in the serialized responses.
     */
    protected string $resourceKey = 'Booking';
}

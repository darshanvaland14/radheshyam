<?php

namespace App\Containers\AppSection\Booking\Models;

use App\Ship\Parents\Models\Model as ParentModel;
use App\Ship\Parents\Models\UserModel as ParentUserModel;
use Illuminate\Database\Eloquent\SoftDeletes;

class Booking extends ParentUserModel
{
    use SoftDeletes;
    protected $table = "hs_user_booking_master";
    protected $fillable = [
        "id",
        "booking_id",
        "hotel_master_id",
        "booking_date",
        "customer_name",
        "email",
        "address",
        "mobile_no",
        "booking_start_date",
        "booking_end_date",
        "notes",
        "no_of_rooms",
        "total_amount",
        "total_tax",
        "advance_amount",
        "due_amount",
    ];

    protected $hidden = [];

    protected $casts = [];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    /**
     * A resource key to be used in the serialized responses.
     */
    protected string $resourceKey = 'Booking';
}

<?php

namespace App\Containers\AppSection\Hotelroom\Actions;

use Apiato\Core\Exceptions\IncorrectIdException;
use App\Containers\AppSection\Hotelroom\Models\Hotelroom;
use App\Containers\AppSection\Hotelroom\Tasks\UpdateHotelroommasterTask;
use App\Containers\AppSection\Hotelroom\UI\API\Requests\UpdateHotelroommasterRequest;
use App\Ship\Exceptions\NotFoundException;
use App\Ship\Exceptions\UpdateResourceFailedException;
use App\Ship\Parents\Actions\Action as ParentAction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Apiato\Core\Traits\HashIdTrait;

class UpdateHotelroommasterAction extends ParentAction
{
    use HashIdTrait;
    public function run(UpdateHotelroommasterRequest $request, $InputData)
    {
          $data = [
              "hotel_master_id" => $this->decode($request->hotel_master_id),
              "room_number" => $request->room_number,
              "room_type_id" => $this->decode($request->room_type_id),
              "room_size_in_sqft" => $request->room_size_in_sqft,
              "occupancy" => $request->occupancy,
              "room_view" => $request->room_view,
              "room_amenities" => $request->room_amenities,
            ];

        return app(UpdateHotelroommasterTask::class)->run($data, $request->id, $InputData);
    }
}

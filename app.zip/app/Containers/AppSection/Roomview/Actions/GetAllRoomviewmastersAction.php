<?php

namespace App\Containers\AppSection\Roomview\Actions;

use Apiato\Core\Exceptions\CoreInternalErrorException;
use App\Containers\AppSection\Roomview\Tasks\GetAllRoomviewmastersTask;
use App\Containers\AppSection\Roomview\UI\API\Requests\GetAllRoomviewmastersRequest;
use App\Ship\Parents\Actions\Action as ParentAction;
use Prettus\Repository\Exceptions\RepositoryException;

class GetAllRoomviewmastersAction extends ParentAction
{
    public function run(GetAllRoomviewmastersRequest $request)
    {
        return app(GetAllRoomviewmastersTask::class)->run();
    }
}

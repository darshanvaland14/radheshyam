<?php

/**
 * @apiGroup           Roomview
 * @apiName            getAllRoomviewmasters
 *
 * @api                {GET} /v1/getallRoomviewmasters Get All Roomview
 * @apiDescription     Endpoint description here...
 *
 * @apiVersion         1.0.0
 * @apiPermission      Authenticated ['permissions' => '', 'Roomviews' => '']
 *
 * @apiHeader          {String} accept=application/json
 * @apiHeader          {String} authorization=Bearer
 *
 * @apiParam           {String} parameters here...
 *
 * @apiSuccessExample  {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *     // Insert the response of the request here...
 * }
 */

use App\Containers\AppSection\Roomview\UI\API\Controllers\Controller;
use Illuminate\Support\Facades\Route;

Route::get('getallroomviewmasterswithpagination', [Controller::class, 'getAllRoomviewmasterswithpagination'])
->middleware(['auth:tenant']);
